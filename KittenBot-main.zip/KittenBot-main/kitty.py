import discord, aiohttp
from discord.ext import commands
from dateutil import parser

token = 'OTUzNjg1MTAyODM0MTEwNDk0.YjIKdw.--G-lbyz3Q57xxjGEKYqyIyqqOU' # Your bot's token
cookie = '_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_68C30CB37E41F085BF62A78AC08EE2E445ACE8B007468A66874432038ACCD8D2C60F50855171A480BC11990F5CBA78B4F336E058DB747C7448942C80D44FBAC3F38B3BBF3132F08AC6EFBED150B11639E7B48DDE9E6E35FFF7628762434FE02DADD3B0B830817D12089B60E2BFC4FB04F9D97D4F4D236617761FD1173707F45D3E4DBBCA39B0BFC7A1A5637F2378B186FD40F4A06DE9403A6DD549E15182CCD05146A56442751073DB2930101DBB21DA25ED6E60F22E9A6F19CE69CDA27E48939720B9813C0E66B103638CA2E97275F182F810A152524DE38E188F2DE1A2F9DA9F3C4498BF1158280009DE8EC988EECC916DAAC459E0255684A239B177D9246723C3D4BDA6043B401FD443613A30725A65E917195CA230CFE13D3871D017D155FCF0BBC1204C0F1DB5168F74955733B74E7D9D6F35D7ADEE086FAAF7989A02945E95C6D98633FE273A24A74015D1F8F3D0A9FB24B5A17EADF7EE22BFB6AEF52DB7AC49912C0921F0E007744B0C29FB0E9A61C26B2E3EB66E2A409A9048AE4C095309F74C' # Your Roblox cookie
prefix = '.' # Commands prefix
group_id = 13802419 # Group ID
UID = 3242875774 # Your Roblox profile UID
intents = discord.Intents.default()
intents.message_content = True
username = None # Do not touch this
user_id = None # Do not touch this
bot = commands.Bot(command_prefix=prefix,intents=intents)
bot.remove_command('help')

class Dropdown(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label='1M', description='1M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='2M', description='2M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='3M', description='3M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='4M', description='4M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='5M', description='5M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='6M', description='6M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='7M', description='7M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='8M', description='8M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='9M', description='9M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='10M', description='10M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='20M', description='20M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='30M', description='30M Da Hood Cash', emoji='💰'),
            discord.SelectOption(label='+', description='Over 30M Da Hood Cash', emoji='💰')
        ]

        super().__init__(placeholder='Select:', min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == '1M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585385165/1-mil')
        if self.values[0] == '2M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585386752/2-mil')
        if self.values[0] == '3M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585393190/3-mil')
        if self.values[0] == '4M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585394319/4-mil')
        if self.values[0] == '5M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585395377/5-mil')
        if self.values[0] == '6M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585396602/6-mil')
        if self.values[0] == '7M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585398698/7-mil')
        if self.values[0] == '8M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585403839/8-mil')
        if self.values[0] == '9M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585400398/9-mil')
        if self.values[0] == '10M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/8585402160/10-mil')
        if self.values[0] == '20M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/9117140746/20-mil')
        if self.values[0] == '30M':
            await interaction.response.send_message(f'Purchase&ping a seller when done.\nhttps://www.roblox.com/catalog/9117146807/30-mil')
        if self.values[0] == '+':
            await interaction.response.send_message(f' Over 30M')


class DropdownView(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.add_item(Dropdown())

@bot.event
async def on_ready():
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=".help"))
    global username
    global user_id
    headers = {
        'Content-Type': 'application/json',
        'Cookie': f'.ROBLOSECURITY={cookie}'
    }
    async with aiohttp.ClientSession() as session:
        async with session.get('https://www.roblox.com/my/account/json', headers=headers) as r:
            r = await r.json()
            name = r['Name']
            user = r['UserId']
    username = name
    user_id = user
    print('Ready')

@bot.event
async def on_guild_channel_create(channel):
    await bot.wait_for('message')
    if channel.name.startswith('ticket-'):
        view = DropdownView()
        await channel.send('Choose the amount of DHC you would like to purchase:', view=view)

@bot.command()
@commands.has_permissions(administrator=True)
async def help(ctx):
    embed = discord.Embed(color=0x0052FF)
    embed.add_field(name='Help', value=f'`{bot.command_prefix}help`', inline=True)
    embed.add_field(name='Balance', value=f'`{bot.command_prefix}balance`', inline=True)
    embed.add_field(name='Sales', value=f'`{bot.command_prefix}sales`', inline=True)
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def balance(ctx):
    headers = {
        'Content-Type': 'application/json',
        'Cookie': f'.ROBLOSECURITY={cookie}'
    }
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.roblox.com/currency/balance', headers=headers) as r:
            r = await r.json()
            robux = r['robux']
        async with session.get(f'https://economy.roblox.com/v2/users/{UID}/transaction-totals?timeFrame=Month&transactionType=summary', headers=headers) as r:
            r = await r.json()
            pendingRobux = r['pendingRobuxTotal']
    embed = discord.Embed(color=0x0052FF)
    embed.add_field(name='Robux', value=f'`{robux} R$`', inline=False)
    embed.add_field(name='Pending', value=f'`{pendingRobux} R$`', inline=False)
    embed.add_field(name='Total', value=f'`{robux + pendingRobux} R$`', inline=False)
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def sales(ctx):
    headers = {
        'Content-Type': 'application/json',
        'Cookie': f'.ROBLOSECURITY={cookie}'
    }
    sales = []
    async with aiohttp.ClientSession() as session:
        async with session.get(f'https://economy.roblox.com/v2/groups/{group_id}/transactions?cursor=&limit=100&sortOrder=Asc&transactionType=Sale', headers=headers) as r:
            r = await r.json()
            for sale in r['data']:
                userid = sale['agent']['id']
                username = sale['agent']['name']
                clothing_name = sale['details']['name']
                price = sale['currency']['amount']
                date = sale['created']
                date = parser.parse(date)
                formatted = date.strftime('%d/%m/%Y | %H:%M')
                sales.append(f'```Username: {username}\nUID: {userid}\nAsset name: {clothing_name}\nPrice: {price}\nDate: {formatted}```\n\n')
    sales = '\n'.join(sales[:10])
    embed = discord.Embed(title='Past 10 sales:', color=0x0052FF, description=f'{sales}')
    await ctx.send(embed=embed)

bot.run(token)

